NeuralThink

The source code files of the world's first auto trainable artificial general intelligence built using Python and other open source libraries. This algorithm can access the camera, the microphone, the speaker, the interent, the calender, the todo, the weather and so on which is typically built to be used on robots withe the inbuilt support system of Arduino.